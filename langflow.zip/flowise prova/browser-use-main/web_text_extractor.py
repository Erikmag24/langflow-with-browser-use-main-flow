from browser_use import Agent, Browser, Controller, ActionResult, BrowserConfig
from langchain_openai import ChatOpenAI
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_anthropic import ChatAnthropic
from pydantic import SecretStr
import asyncio
import os
import sys
from dotenv import load_dotenv
from typing import Optional, Literal
from bs4 import BeautifulSoup

# Carica le variabili d'ambiente dal file .env nella sottocartella browser-use-main-p
env_path = os.path.join(os.path.dirname(__file__), 'browser-use-main-p', '.env')
load_dotenv(env_path)

async def extract_text_from_web(query: str, num_results: int = 3, api_key: Optional[str] = None, 
                              provider: Literal["openai", "gemini", "claude"] = "gemini",
                              model: Optional[str] = None) -> str:
    """
    Funzione semplificata per estrarre testo dalle pagine web basate su una query di ricerca.
    
    Args:
        query (str): La query di ricerca
        num_results (int, optional): Numero di risultati da processare. Default è 3.
        api_key (str, optional): API key per il provider scelto. Se non fornita, usa la variabile d'ambiente appropriata
        provider (str, optional): Provider LLM da utilizzare ("openai", "gemini" o "claude"). Default è "gemini".
        model (str, optional): Modello da utilizzare. Se non specificato, usa il default per il provider.
        
    Returns:
        str: Testo estratto da tutte le pagine visitate
    """
    # Configurazione del controller con la funzione di estrazione testo
    controller = Controller()
    
    @controller.action('Estrai tutto il testo dalla pagina corrente')
    async def extract_text(browser: Browser) -> ActionResult:
        page = browser.get_current_page()
        current_url = await page.url()
        
        # Ottieni il contenuto HTML
        html_content = await page.content()
        
        # Analisi con BeautifulSoup
        soup = BeautifulSoup(html_content, 'html.parser')
        
        # Rimuovi script e style elements
        for script in soup(["script", "style"]):
            script.extract()
        
        # Estrai il testo
        text = soup.get_text(separator='\n')
        
        # Pulizia del testo
        lines = (line.strip() for line in text.splitlines())
        cleaned_text = '\n'.join(line for line in lines if line)
        
        return ActionResult(extracted_content=f"Testo estratto da {current_url}:\n\n{cleaned_text}")
    
    # Define default models for each provider
    default_models = {
        "openai": "gpt-4o",
        "claude": "claude-3-7-sonnet-20250219",
        "gemini": "gemini-2.0-flash-exp"
    }
    
    # If provider is passed as model name, adjust accordingly
    if provider in ["openai", "claude", "gemini"] and model in ["openai", "claude", "gemini"]:
        provider, model = model, None
    
    # Auto-detect provider from model name if possible
    if model:
        if model.startswith('gpt') or model.startswith('text-'):
            provider = 'openai'
        elif model.startswith('claude'):
            provider = 'claude'
        elif model.startswith('gemini'):
            provider = 'gemini'
    
    # Set default model if not specified
    if model is None and provider in default_models:
        model = default_models[provider]
    
    # Configura LLM in base al provider
    if provider == "openai":
        # Usa l'API key fornita o prendi quella da variabili d'ambiente
        if not api_key:
            api_key = os.getenv("OPENAI_API_KEY")
            if not api_key:
                raise ValueError("OpenAI API key non trovata. Forniscila come parametro o in .env come OPENAI_API_KEY")
        
        print(f"Using OpenAI model: {model}")
        llm = ChatOpenAI(
            model=model,
            api_key=api_key
        )
    elif provider == "claude":
        # Usa l'API key fornita o prendi quella da variabili d'ambiente
        if not api_key:
            api_key = os.getenv("ANTHROPIC_API_KEY")
            if not api_key:
                raise ValueError("Anthropic API key non trovata. Forniscila come parametro o in .env come ANTHROPIC_API_KEY")
        
        print(f"Using Claude model: {model}")
        llm = ChatAnthropic(
            model=model,
            api_key=api_key
        )
    else:  # gemini
        # Usa l'API key fornita o prendi quella da variabili d'ambiente
        if not api_key:
            api_key = os.getenv("GEMINI_API_KEY")
            if not api_key:
                raise ValueError("Gemini API key non trovata. Forniscila come parametro o in .env come GEMINI_API_KEY")
        
        print(f"Using Gemini model: {model}")
        llm = ChatGoogleGenerativeAI(
            model=model,
            api_key=SecretStr(api_key)
        )
    
    # Configura il browser
    browser = Browser(
        config=BrowserConfig(
            headless=True,  # Esegui in background
            disable_security=True
        )
    )
    
    # Crea l'agente con un task specifico per la query
    task = f"""
    Cerca \"{query}\" su Google, visita i primi {num_results} risultati e per ogni pagina estrai tutto il testo.
    Alla fine restituisci tutti i contenuti testuali estratti.
    """
    
    agent = Agent(
        task=task,
        llm=llm,
        browser=browser,
        controller=controller
    )
    
    try:
        # Esegui l'agente
        history = await agent.run()
        
        # Raccogli tutti i contenuti estratti
        extracted_contents = history.extracted_content()
        
        # Componi il risultato finale
        final_text = ""
        for content in extracted_contents:
            if content and isinstance(content, str):
                final_text += content + "\n\n" + "-" * 80 + "\n\n"
        
        return final_text
    
    finally:
        # Chiudi sempre il browser
        await browser.close()

def search_and_extract(query: str, num_results: int = 3, api_key: Optional[str] = None, 
                      provider: Literal["openai", "gemini", "claude"] = "claude",
                      model: Optional[str] = None) -> str:
    """
    Funzione sincrona per estrarre testo dalle pagine web basate su una query di ricerca.
    
    Args:
        query (str): La query di ricerca
        num_results (int, optional): Numero di risultati da processare. Default è 3.
        api_key (str, optional): API key per il provider scelto. Se non fornita, usa la variabile d'ambiente appropriata
        provider (str, optional): Provider LLM da utilizzare ("openai", "gemini" o "claude"). Default è "gemini".
        model (str, optional): Modello da utilizzare. Se non specificato, usa il default per il provider.
        
    Returns:
        str: Testo estratto da tutte le pagine visitate
    """
    return asyncio.run(extract_text_from_web(query, num_results, api_key, provider, model))
