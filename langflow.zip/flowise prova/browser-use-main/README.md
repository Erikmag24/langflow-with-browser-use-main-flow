# Web Text Extractor

Questo progetto fornisce una funzione semplificata per estrarre testo da pagine web basate su una query di ricerca. Utilizza il framework Browser Use per automatizzare la navigazione web e l'estrazione del contenuto.

## Funzionalità

- Ricerca su Google in base a una query fornita
- Visita automaticamente i primi N risultati di ricerca
- Estrae il testo da ogni pagina visitata
- Restituisce tutto il testo estratto in un formato facilmente utilizzabile

## Requisiti

- Python 3.11 o superiore
- Browser Use framework
- BeautifulSoup4
- API key per OpenAI o Google Gemini

## Installazione

1. Clona questo repository
2. Installa le dipendenze: `pip install -r requirements.txt`
3. Copia il file `.env.example` in `.env` e aggiungi le tue chiavi API

## Utilizzo

Importa la funzione `search_and_extract` nel tuo codice:

```python
from web_text_extractor import search_and_extract

# Estrai testo da pagine web basate su una query
risultato = search_and_extract(
    query="intelligenza artificiale news",  # La tua query di ricerca
    num_results=3,                        # Numero di risultati da processare (default: 3)
    provider="gemini",                     # Provider LLM: "openai" o "gemini" (default: "gemini")
    model=None                            # Modello da utilizzare (se None, usa il default del provider)
)

# Stampa o elabora il risultato
print(risultato)

# Salva il risultato in un file
with open("risultato_ricerca.txt", "w", encoding="utf-8") as f:
    f.write(risultato)
```

## Esempio

Puoi eseguire l'esempio incluso:

```bash
python esempio_uso.py
```

Questo eseguirà una ricerca di esempio e salverà i risultati in un file di testo.

## Configurazione

Per utilizzare questa funzione, devi avere una chiave API per OpenAI o Google Gemini. Puoi configurare queste chiavi nel file `.env`:

```
# API key per OpenAI
OPENAI_API_KEY=sk-your-openai-api-key-here

# API key per Google Gemini
GEMINI_API_KEY=your-gemini-api-key-here
```

## Note

- Il browser viene eseguito in modalità headless (senza interfaccia grafica) per default
- La funzione gestisce automaticamente l'apertura e la chiusura del browser
- Il testo estratto viene pulito e formattato per una migliore leggibilità
