from browser_use import Agent, Browser, Controller, ActionResult, BrowserConfig
from langchain_google_genai import ChatGoogleGenerativeAI
from pydantic import BaseModel, SecretStr, Field
from typing import List, Optional, Union
import asyncio
import os
from dotenv import load_dotenv
import json
from bs4 import BeautifulSoup
import requests
from urllib.parse import urljoin, urlparse
import re
import time
import logging

# Configurazione logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

load_dotenv()

# Modelli Pydantic per i parametri strutturati
class ContentType(BaseModel):
    extract_text: bool = Field(default=False, description="Estrai il testo dalla pagina")
    extract_images: bool = Field(default=False, description="Estrai le immagini dalla pagina")
    extract_videos: bool = Field(default=False, description="Estrai i video dalla pagina")

class SearchQuery(BaseModel):
    query: str = Field(description="Query di ricerca")
    num_results: int = Field(default=3, description="Numero di risultati da processare")
    content_type: ContentType = Field(description="Tipo di contenuto da estrarre")

# Controller personalizzato con funzioni di estrazione
controller = Controller()

# Funzione per estrarre tutto il testo dalla pagina corrente
@controller.action('Estrai tutto il testo dalla pagina corrente')
async def extract_text(browser: Browser) -> ActionResult:
    logger.info("Estrazione del testo dalla pagina corrente...")
    page = browser.get_current_page()
    current_url = await page.url()
    
    # Ottieni il contenuto HTML
    html_content = await page.content()
    
    # Analisi con BeautifulSoup
    soup = BeautifulSoup(html_content, 'html.parser')
    
    # Rimuovi script e style elements
    for script in soup(["script", "style"]):
        script.extract()
    
    # Estrai il testo
    text = soup.get_text(separator='\n')
    
    # Pulizia del testo
    lines = (line.strip() for line in text.splitlines())
    cleaned_text = '\n'.join(line for line in lines if line)
    
    logger.info(f"Testo estratto da {current_url} - {len(cleaned_text)} caratteri")
    
    return ActionResult(extracted_content=f"Testo estratto da {current_url}:\n\n{cleaned_text[:500]}...\n[Testo completo: {len(cleaned_text)} caratteri]")

# Funzione per estrarre tutte le immagini dalla pagina corrente
@controller.action('Estrai tutte le immagini dalla pagina corrente')
async def extract_images(browser: Browser) -> ActionResult:
    logger.info("Estrazione delle immagini dalla pagina corrente...")
    page = browser.get_current_page()
    current_url = await page.url()
    base_url = current_url
    
    # Ottieni il contenuto HTML
    html_content = await page.content()
    
    # Analisi con BeautifulSoup
    soup = BeautifulSoup(html_content, 'html.parser')
    
    # Estrai le URL delle immagini
    images = []
    for img in soup.find_all('img'):
        src = img.get('src', '')
        if src and not src.startswith('data:'):
            # Gestisci gli URL relativi
            if not src.startswith(('http://', 'https://')):
                src = urljoin(base_url, src)
            
            alt_text = img.get('alt', 'No alt text')
            images.append({
                'url': src,
                'alt': alt_text,
                'width': img.get('width', 'unknown'),
                'height': img.get('height', 'unknown')
            })
    
    logger.info(f"Immagini estratte da {current_url} - {len(images)} immagini trovate")
    
    return ActionResult(extracted_content=json.dumps({
        'page_url': current_url,
        'total_images': len(images),
        'images': images[:50]  # Limita a 50 immagini per evitare risposte troppo lunghe
    }, indent=2))

# Funzione per estrarre tutti i video dalla pagina corrente
@controller.action('Estrai tutti i video dalla pagina corrente')
async def extract_videos(browser: Browser) -> ActionResult:
    logger.info("Estrazione dei video dalla pagina corrente...")
    page = browser.get_current_page()
    current_url = await page.url()
    
    # Ottieni il contenuto HTML
    html_content = await page.content()
    
    # Analisi con BeautifulSoup
    soup = BeautifulSoup(html_content, 'html.parser')
    
    # Estrai le URL dei video da varie fonti
    videos = []
    
    # 1. Tag video
    for video in soup.find_all('video'):
        src = video.get('src', '')
        if src:
            if not src.startswith(('http://', 'https://')):
                src = urljoin(current_url, src)
            videos.append({
                'type': 'video tag',
                'url': src,
                'attributes': {
                    'width': video.get('width', 'unknown'),
                    'height': video.get('height', 'unknown'),
                    'controls': video.has_attr('controls')
                }
            })
        
        # Controlla anche i tag source all'interno di video
        for source in video.find_all('source'):
            src = source.get('src', '')
            if src:
                if not src.startswith(('http://', 'https://')):
                    src = urljoin(current_url, src)
                videos.append({
                    'type': 'video source',
                    'url': src,
                    'mime_type': source.get('type', 'unknown')
                })
    
    # 2. Iframes (YouTube, Vimeo, ecc.)
    for iframe in soup.find_all('iframe'):
        src = iframe.get('src', '')
        if src:
            if 'youtube.com' in src or 'youtu.be' in src:
                video_type = 'YouTube'
            elif 'vimeo.com' in src:
                video_type = 'Vimeo'
            else:
                video_type = 'iframe'
            
            videos.append({
                'type': video_type,
                'url': src,
                'attributes': {
                    'width': iframe.get('width', 'unknown'),
                    'height': iframe.get('height', 'unknown')
                }
            })
    
    logger.info(f"Video estratti da {current_url} - {len(videos)} video trovati")
    
    return ActionResult(extracted_content=json.dumps({
        'page_url': current_url,
        'total_videos': len(videos),
        'videos': videos
    }, indent=2))

# Salva il contenuto estratto in un file
@controller.action('Salva contenuto su file')
def save_to_file(content: str, filename: str) -> ActionResult:
    try:
        with open(filename, 'w', encoding='utf-8') as f:
            f.write(content)
        logger.info(f"Contenuto salvato in {filename}")
        return ActionResult(extracted_content=f"Contenuto salvato con successo in {filename}")
    except Exception as e:
        error_msg = f"Errore nel salvare il file: {str(e)}"
        logger.error(error_msg)
        return ActionResult(extracted_content=error_msg, error=True)

# Funzione per cercare e processare più link
@controller.action('Cerca e processa link in base ai criteri specificati')
async def search_and_process(params: SearchQuery, browser: Browser) -> ActionResult:
    query = params.query
    num_results = params.num_results
    content_type = params.content_type
    
    logger.info(f"Ricerca di '{query}' - analisi dei primi {num_results} risultati")
    logger.info(f"Tipi di contenuto richiesti: Testo={content_type.extract_text}, Immagini={content_type.extract_images}, Video={content_type.extract_videos}")
    
    page = browser.get_current_page()
    
    # Vai alla pagina di Google
    await page.goto("https://www.google.com")
    
    # Cerca la query
    search_box = await page.query_selector('input[name="q"]')
    await search_box.fill(query)
    await search_box.press('Enter')
    
    # Attendi il caricamento dei risultati
    await page.wait_for_selector('div#search')
    
    # Raccogli i link dai risultati
    search_results = await page.query_selector_all('div.g a')
    result_links = []
    
    for i, result in enumerate(search_results):
        if i >= num_results:
            break
        
        href = await result.get_attribute('href')
        if href and href.startswith('http'):
            result_links.append(href)
    
    # Risultati trovati
    logger.info(f"Trovati {len(result_links)} link da processare")
    
    all_results = {
        'query': query,
        'num_results_found': len(result_links),
        'results': []
    }
    
    # Processa ogni link
    for i, link in enumerate(result_links):
        logger.info(f"Processando il link {i+1}/{len(result_links)}: {link}")
        
        result_data = {'url': link, 'data': {}}
        
        # Vai al link
        try:
            await page.goto(link, timeout=30000)
            await page.wait_for_load_state('networkidle', timeout=10000)
            
            # Estrai il contenuto richiesto
            if content_type.extract_text:
                text_result = await extract_text(browser)
                result_data['data']['text'] = text_result.extracted_content
            
            if content_type.extract_images:
                images_result = await extract_images(browser)
                result_data['data']['images'] = json.loads(images_result.extracted_content)
            
            if content_type.extract_videos:
                videos_result = await extract_videos(browser)
                result_data['data']['videos'] = json.loads(videos_result.extracted_content)
                
            all_results['results'].append(result_data)
            
        except Exception as e:
            logger.error(f"Errore nel processare {link}: {str(e)}")
            result_data['error'] = str(e)
            all_results['results'].append(result_data)
    
    logger.info(f"Completata l'analisi di {len(all_results['results'])} pagine")
    
    # Salva i risultati in un file
    timestamp = int(time.time())
    results_filename = f"search_results_{timestamp}.json"
    with open(results_filename, 'w', encoding='utf-8') as f:
        json.dump(all_results, f, indent=2, ensure_ascii=False)
    
    return ActionResult(extracted_content=f"Ricerca completata. Processati {len(all_results['results'])} link. Risultati salvati in {results_filename}")

async def main():
    # Configura il modello con la chiave API di Gemini
    api_key = os.getenv("GEMINI_API_KEY")
    if not api_key:
        raise ValueError("GEMINI_API_KEY non trovata nelle variabili d'ambiente. Crea un file .env con la chiave.")
    
    llm = ChatGoogleGenerativeAI(
        model='gemini-2.0-flash-exp', 
        api_key=SecretStr(api_key)
    )
    
    # Configura il browser
    browser_config = BrowserConfig(
        headless=False,  # Imposta su True per eseguire in background
        disable_security=True
    )
    
    browser = Browser(config=browser_config)
    
    # Crea l'agente con il controller personalizzato
    task = """
    Cerca "intelligenza artificiale news" e analizza i primi 3 risultati.
    Per ogni pagina, estrai il testo, le immagini e i video.
    Salva i risultati in file separati.
    """
    
    agent = Agent(
        task=task,
        llm=llm,
        browser=browser,
        controller=controller
    )
    
    try:
        # Esegui l'agente
        logger.info("Avvio dell'agente...")
        history = await agent.run()
        result = history.final_result()
        logger.info(f"Risultato finale: {result}")
        
    except Exception as e:
        logger.error(f"Errore durante l'esecuzione: {str(e)}")
    
    finally:
        # Chiudi sempre il browser
        logger.info("Chiusura del browser...")
        await browser.close()

if __name__ == '__main__':
    asyncio.run(main())
