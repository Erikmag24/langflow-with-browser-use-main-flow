from flask import Flask, request, jsonify
import os
import sys
from dotenv import load_dotenv
from web_text_extractor import search_and_extract
import argparse

# Carica le variabili d'ambiente dal file .env
env_path = os.path.join(os.path.dirname(__file__), 'browser-use-main-p', '.env')
load_dotenv(env_path)

app = Flask(__name__)

# Memorizza i modelli supportati
SUPPORTED_MODELS = {
    "gemini": {
        "env_key": "GEMINI_API_KEY",
        "default_model": "gemini-2.0-flash-exp"
    },
    "openai": {
        "env_key": "OPENAI_API_KEY",
        "default_model": "gpt-4o"
    },
    "claude": {
        "env_key": "ANTHROPIC_API_KEY",
        "default_model": "claude-3-opus-20240229"
    }
}

@app.route('/')
def home():
    models = list(SUPPORTED_MODELS.keys())
    return f"""
    <html>
    <head><title>Web Text Extractor API</title></head>
    <body>
        <h1>Server API per Web Text Extractor</h1>
        <p>Usa <code>/api/extract</code> per le richieste.</p>
        <h2>Modelli supportati:</h2>
        <ul>{"".join([f"<li>{model}</li>" for model in models])}</ul>
        <h2>Esempio di richiesta POST:</h2>
        <pre>
curl -X POST http://localhost:5000/api/extract \\
  -H "Content-Type: application/json" \\
  -d '{{"query": "intelligenza artificiale", 
       "num_results": 1, 
       "provider": "claude", 
       "api_key": "insert_api_key",
       "model": "modello_specifico_opzionale"}}'
        </pre>
        <h2>Esempio di richiesta GET:</h2>
        <pre>
curl -X GET "http://localhost:5000/api/extract?query=intelligenza+artificiale&num_results=1&provider=claude"
        </pre>
    </body>
    </html>
    """

@app.route('/api/extract', methods=['GET', 'POST'])
def extract_web_content():
    """
    Endpoint API per estrarre contenuto web da una query di ricerca.
    
    Supporta opzioni per:
    - query: query di ricerca 
    - num_results: numero di risultati da processare
    - provider: provider AI da utilizzare (gemini, openai, claude)
    - api_key: API key personalizzata (opzionale)
    - model: modello specifico da utilizzare (opzionale)
    """
    try:
        # Supporta sia GET che POST
        if request.method == 'POST':
            data = request.get_json(silent=True) or {}
        else:  # GET
            data = request.args.to_dict()
        
        # Parametri obbligatori
        if 'query' not in data:
            return jsonify({"error": "Parametro 'query' mancante"}), 400
            
        query = data.get('query')
        
        # Parametri opzionali con valori predefiniti
        try:
            num_results = int(data.get('num_results', 1))
        except:
            num_results = 1
            
        provider = data.get('provider', 'gemini')
        
        # Controlla se il provider è supportato
        if provider not in SUPPORTED_MODELS:
            return jsonify({"error": f"Provider '{provider}' non supportato. Disponibili: {', '.join(SUPPORTED_MODELS.keys())}"}), 400
            
        # Ottieni API key (data nella richiesta o dal file .env)
        api_key = data.get('api_key')
        
        if not api_key:
            # Usa la chiave dal file .env
            env_key_name = SUPPORTED_MODELS[provider]["env_key"]
            api_key = os.getenv(env_key_name)
            
            if not api_key:
                return jsonify({"error": f"Chiave API per {provider} non trovata. Forniscila nella richiesta o configura {env_key_name} nel file .env"}), 400
        
        # Modello specifico (opzionale)
        model = data.get('model')
        
        # Stampa informazioni di debug
        print("="*50)
        print(f"RICHIESTA RICEVUTA:")
        print(f"Query: {query}")
        print(f"Provider: {provider}")
        print(f"Num results: {num_results}")
        print(f"Model: {model if model else 'default'}")
        print(f"API Key (primi 10 caratteri): {api_key[:10]}...{api_key[-5:]} (lunghezza: {len(api_key)})")
        print("="*50)
        
        try:
            # Esegui la ricerca e l'estrazione
            print(f"Chiamata a search_and_extract con provider={provider}")
            result = search_and_extract(
                query=query,
                num_results=num_results,
                provider=provider,
                api_key=api_key,
                model=model
            )
            
            # Stampa info sul risultato
            print(f"Risultato ottenuto, lunghezza: {len(result) if result else 0}")
            
            # Restituisci il risultato come JSON
            return jsonify({
                "success": True,
                "result": result,
                "metadata": {
                    "query": query,
                    "provider": provider,
                    "num_results": num_results,
                    "model": model if model else "default"
                }
            })
            
        except Exception as extract_error:
            error_message = str(extract_error)
            print(f"ERRORE in search_and_extract: {error_message}")
            return jsonify({
                "success": False,
                "error": error_message,
                "phase": "extraction",
                "metadata": {
                    "query": query,
                    "provider": provider,
                    "num_results": num_results
                }
            }), 500
        
    except Exception as e:
        import traceback
        error_details = traceback.format_exc()
        print(f"ERRORE GENERALE: {str(e)}")
        print(error_details)
        return jsonify({
            "success": False, 
            "error": str(e),
            "details": error_details
        }), 500

@app.route('/search', methods=['GET'])
def search_web_content():
    """
    Endpoint API per la ricerca web compatibile con il componente LocalSearchAPI.
    
    Supporta parametri GET:
    - query: query di ricerca (chiamato search_query nel componente)
    - num_results: numero di risultati da processare
    - recursion_depth: profondità di ricerca (ignorato, per compatibilità)
    - api_key: API key personalizzata
    - model: modello da utilizzare
    """
    try:
        # Prendi i parametri dalla richiesta GET
        data = request.args.to_dict()
        
        # Parametri obbligatori
        search_query = data.get('query')
        if not search_query:
            return jsonify({"error": "Parametro 'query' mancante"}), 400
            
        # Parametri opzionali con valori predefiniti
        try:
            num_results = int(data.get('num_results', 2))
        except:
            num_results = 2
        
        # Ottieni il modello e imposta il provider in base al nome del modello
        model = data.get('model', 'gemini')  # default to gemini if not specified
        
        # Determina il provider in base al modello specificato
        if model.startswith('gpt') or model.startswith('text-'):
            provider = 'openai'
        elif model.startswith('claude'):
            provider = 'claude'
        else:  # Default o modello Gemini
            provider = 'gemini'
        
        # Se il provider determinato non è nel modello, usa il valore di model come provider
        if provider not in SUPPORTED_MODELS and model in SUPPORTED_MODELS:
            provider = model
            model = None  # Usa il modello predefinito per il provider
            
        # Controlla se il provider è supportato
        if provider not in SUPPORTED_MODELS:
            return jsonify({"error": f"Provider o modello '{model}' non supportato. Disponibili: {', '.join(SUPPORTED_MODELS.keys())}"}), 400
        
        # Ottieni API key (data nella richiesta o dal file .env)
        api_key = data.get('api_key')
        
        if not api_key:
            # Usa la chiave dal file .env
            env_key_name = SUPPORTED_MODELS[provider]["env_key"]
            api_key = os.getenv(env_key_name)
            
            if not api_key:
                return jsonify({"error": f"Chiave API per {provider} non trovata. Forniscila nella richiesta o configura {env_key_name} nel file .env"}), 400
        
        # Stampa informazioni di debug
        print("="*50)
        print(f"RICHIESTA /search RICEVUTA:")
        print(f"Query: {search_query}")
        print(f"Provider: {provider}")
        print(f"Num results: {num_results}")
        print(f"Model: {model if model else 'default'}")
        print(f"API Key (primi 10 caratteri): {api_key[:10]}...{api_key[-5:]} (lunghezza: {len(api_key)})")
        print("="*50)
        
        try:
            # Esegui la ricerca e l'estrazione
            print(f"Chiamata a search_and_extract con provider={provider}")
            result = search_and_extract(
                query=search_query,
                num_results=num_results,
                provider=provider,
                api_key=api_key,
                model=model
            )
            
            # Stampa info sul risultato
            print(f"Risultato ottenuto, lunghezza: {len(result) if result else 0}")
            
            # Restituisci il risultato come JSON (formato leggermente diverso da /api/extract)
            return jsonify({
                "text": result,
                "metadata": {
                    "query": search_query,
                    "provider": provider,
                    "num_results": num_results,
                    "model": model if model else "default"
                }
            })
            
        except Exception as extract_error:
            error_message = str(extract_error)
            print(f"ERRORE in search_and_extract: {error_message}")
            return jsonify({
                "error": error_message,
                "metadata": {
                    "query": search_query,
                    "provider": provider,
                    "num_results": num_results
                }
            }), 500
        
    except Exception as e:
        import traceback
        error_details = traceback.format_exc()
        print(f"ERRORE GENERALE: {str(e)}")
        print(error_details)
        return jsonify({
            "error": str(e),
            "details": error_details
        }), 500

if __name__ == '__main__':
    # Configurazione tramite argomenti della riga di comando
    parser = argparse.ArgumentParser(description='Web Text Extractor API Server')
    parser.add_argument('--port', type=int, default=5000, help='Porta su cui ascoltare (default: 5000)')
    parser.add_argument('--host', type=str, default='0.0.0.0', help='Host su cui ascoltare (default: 0.0.0.0)')
    parser.add_argument('--debug', action='store_true', help='Avvia in modalità debug')
    
    args = parser.parse_args()
    
    print(f"Server API avviato su http://{args.host}:{args.port}")
    print(f"Endpoint disponibile: http://{args.host}:{args.port}/api/extract")
    print(f"Endpoint per LocalSearchAPI: http://{args.host}:{args.port}/search")
    print(f"Visita http://{args.host}:{args.port}/ per la documentazione")
    print(f"Modelli supportati: {', '.join(SUPPORTED_MODELS.keys())}")
    
    # Avvia con Flask standard, senza waitress
    app.run(debug=False, host=args.host, port=args.port)
